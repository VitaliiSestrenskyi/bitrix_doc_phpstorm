<?
/**
 * SITE_TEMPLATE_ID
 */
define('SITE_TEMPLATE_ID', $arParams['siteTemplateId']);

/**
 * BX_B_MEDIALIB_SCRIPT_LOADED
 */
define('BX_B_MEDIALIB_SCRIPT_LOADED', true);

/**
 * DEBUG_FILE_MAN
 */
define('DEBUG_FILE_MAN', false);

/**
 * CACHED_stickers_count
 */
define('CACHED_stickers_count', 36000000);

/**
 * ADMIN_MODULE_NAME
 */
define('ADMIN_MODULE_NAME', "fileman");

/**
 * ADMIN_MODULE_ICON
 */
define('ADMIN_MODULE_ICON', "<a href=\"/bitrix/admin/fileman_admin.php?lang=".LANG."\"><img src=\"/bitrix/images/fileman/fileman.gif\" width=\"48\" height=\"48\" border=\"0\" alt=\"".GetMessage("FILEMAN_ICON_ALT")."\" title=\"".GetMessage("FILEMAN_ICON_ALT")."\"></a>");


?>