<?
global $MESS;
IncludeModuleLangFile(__FILE__);

// define("ADMIN_MODULE_NAME", "fileman");
// define("ADMIN_MODULE_ICON", "<a href=\"/bitrix/admin/fileman_admin.php?lang=".LANG."\"><img src=\"/bitrix/images/fileman/fileman.gif\" width=\"48\" height=\"48\" border=\"0\" alt=\"".GetMessage("FILEMAN_ICON_ALT")."\" title=\"".GetMessage("FILEMAN_ICON_ALT")."\"></a>");

?>