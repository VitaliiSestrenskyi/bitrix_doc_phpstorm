<?
/**
 * FORM_CRM_DEFAULT_PATH
 */
define('FORM_CRM_DEFAULT_PATH', '/crm/configs/import/lead.php');

/**
 * ADMIN_MODULE_NAME
 */
define('ADMIN_MODULE_NAME', "form");

/**
 * ADMIN_MODULE_ICON
 */
define('ADMIN_MODULE_ICON', "<a href=\"form_list.php?lang=".LANGUAGE_ID."\"><img src=\"/bitrix/images/form/form.gif\" width=\"48\" height=\"48\" border=\"0\" alt=\"".GetMessage("FORM_MODULE_TITLE")."\" title=\"".GetMessage("FORM_MODULE_TITLE")."\"></a>");


?>