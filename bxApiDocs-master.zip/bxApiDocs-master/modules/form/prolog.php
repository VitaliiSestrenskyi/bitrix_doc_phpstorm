<?
IncludeModuleLangFile(__FILE__);

// define("ADMIN_MODULE_NAME", "form");
// define("ADMIN_MODULE_ICON", "<a href=\"form_list.php?lang=".LANGUAGE_ID."\"><img src=\"/bitrix/images/form/form.gif\" width=\"48\" height=\"48\" border=\"0\" alt=\"".GetMessage("FORM_MODULE_TITLE")."\" title=\"".GetMessage("FORM_MODULE_TITLE")."\"></a>");
//$APPLICATION->SetAdditionalCSS("/bitrix/modules/form/form_admin.css");
?>