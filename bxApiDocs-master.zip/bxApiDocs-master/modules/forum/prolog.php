<?
// define("ADMIN_MODULE_NAME", "forum");
IncludeModuleLangFile(__FILE__);
// define("ADMIN_MODULE_ICON", "<img src=\"/bitrix/images/forum/forum.gif\" width=\"48\" height=\"48\" border=\"0\" alt=\"".GetMessage("FORUM_ICON_TITLE")."\" title=\"".GetMessage("FORUM_ICON_TITLE")."\">");
?>