<?
/**
 * FORUM_SystemFolder
 */
define('FORUM_SystemFolder', 4);

/**
 * CACHED_b_forum_group
 */
define('CACHED_b_forum_group', 3600);

/**
 * CACHED_b_forum
 */
define('CACHED_b_forum', 3600);

/**
 * CACHED_b_forum_perms
 */
define('CACHED_b_forum_perms', 3600);

/**
 * CACHED_b_forum2site
 */
define('CACHED_b_forum2site', 3600);

/**
 * CACHED_b_forum_filter
 */
define('CACHED_b_forum_filter', 3600);

/**
 * CACHED_b_forum_user
 */
define('CACHED_b_forum_user', 3600);

/**
 * ADMIN_MODULE_NAME
 */
define('ADMIN_MODULE_NAME', "forum");

/**
 * ADMIN_MODULE_ICON
 */
define('ADMIN_MODULE_ICON', "<img src=\"/bitrix/images/forum/forum.gif\" width=\"48\" height=\"48\" border=\"0\" alt=\"".GetMessage("FORUM_ICON_TITLE")."\" title=\"".GetMessage("FORUM_ICON_TITLE")."\">");


?>