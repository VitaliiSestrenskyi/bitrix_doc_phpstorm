<?
// define("ADMIN_MODULE_NAME", "blog");
IncludeModuleLangFile(__FILE__);
// define("ADMIN_MODULE_ICON", "<a href=\"/bitrix/admin/blog.php?lang=".LANG."\"><img src=\"/bitrix/images/blog/blog.gif\" width=\"48\" height=\"48\" border=\"0\" alt=\"".GetMessage("BLOG_ICON_TITLE")."\" title=\"".GetMessage("BLOG_ICON_TITLE")."\"></a>");
?>