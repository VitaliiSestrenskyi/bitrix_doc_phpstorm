<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/catalog/general/admin_tools.php");

class CCatalogAdminTools extends CCatalogAdminToolsAll
{

}
?>