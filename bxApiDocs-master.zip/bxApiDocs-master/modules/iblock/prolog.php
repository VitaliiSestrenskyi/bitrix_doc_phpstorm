<?
IncludeModuleLangFile(__FILE__);
// define("ADMIN_MODULE_NAME", "iblock");
// define("ADMIN_MODULE_ICON", "<img src=\"/bitrix/images/iblock/iblock.gif\" width=\"48\" height=\"48\" border=\"0\" alt=\"".GetMessage("IBLOCK_ICON_HINT")."\" title=\"".GetMessage("IBLOCK_ICON_HINT")."\">");
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/iblock/admin_tools.php");
?>