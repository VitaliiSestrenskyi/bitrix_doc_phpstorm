<?
/**
 * BT_UT_SKU_CODE
 */
define('BT_UT_SKU_CODE', 'SKU');

/**
 * ADMIN_AJAX_MODE
 */
define('ADMIN_AJAX_MODE', true);

/**
 * CACHED_b_iblock_type
 */
define('CACHED_b_iblock_type', 36000);

/**
 * CACHED_b_iblock
 */
define('CACHED_b_iblock', 36000);

/**
 * CACHED_b_iblock_bucket_size
 */
define('CACHED_b_iblock_bucket_size', 20);

/**
 * CACHED_b_iblock_property_enum
 */
define('CACHED_b_iblock_property_enum', 36000);

/**
 * CACHED_b_iblock_property_enum_bucket_size
 */
define('CACHED_b_iblock_property_enum_bucket_size', 100);

/**
 * ERROR_404
 */
define('ERROR_404', "Y");

/**
 * ADMIN_MODULE_NAME
 */
define('ADMIN_MODULE_NAME', "iblock");

/**
 * ADMIN_MODULE_ICON
 */
define('ADMIN_MODULE_ICON', "<img src=\"/bitrix/images/iblock/iblock.gif\" width=\"48\" height=\"48\" border=\"0\" alt=\"".GetMessage("IBLOCK_ICON_HINT")."\" title=\"".GetMessage("IBLOCK_ICON_HINT")."\">");

/**
 * ADMIN_SECTION
 */
define('ADMIN_SECTION', true);


?>