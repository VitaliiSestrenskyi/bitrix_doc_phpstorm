<?php
namespace Bitrix\Iblock;

/**
 * Class SiteTable
 * @package Bitrix\Iblock
 * @deprecated
 */
class SiteTable extends IblockSiteTable
{
}
