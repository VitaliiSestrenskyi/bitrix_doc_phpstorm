<?
// define('ADMIN_MODULE_NAME', 'currency');
IncludeModuleLangFile(__FILE__);
// define('ADMIN_MODULE_ICON', '<a href="/bitrix/admin/currencies_rates.php?lang='.LANGUAGE_ID.'"><img src="/bitrix/images/currency/currency.gif" width="48" height="48" border="0" alt="'.GetMessage('CURRENCY_ICON_TITLE').'" title="'.GetMessage('CURRENCY_ICON_TITLE').'"></a>');
?>