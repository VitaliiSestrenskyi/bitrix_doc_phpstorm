<?
/**
 * BP_EI_DIRECTION_EXPORT
 */
define('BP_EI_DIRECTION_EXPORT', 0);

/**
 * BP_EI_DIRECTION_IMPORT
 */
define('BP_EI_DIRECTION_IMPORT', 1);

/**
 * ADMIN_MODULE_NAME
 */
define('ADMIN_MODULE_NAME', "bizproc");


?>