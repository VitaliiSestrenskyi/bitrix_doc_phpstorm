<?
/**
 * 14.0.0
 */
define('BX_COMP_MANAGED_CACHE', null);

/**
 * BX_UTF
 */
define('BX_UTF', null);

/**
 * OLD_OUTLOOK_VERSION
 */
define('OLD_OUTLOOK_VERSION', null);

/**
 * SITE_SERVER_NAME
 */
define('SITE_SERVER_NAME', null);

/**
 * ADMIN_MODULE_NAME
 */
define('ADMIN_MODULE_NAME', "calendar");


?>