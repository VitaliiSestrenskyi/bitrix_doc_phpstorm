<?
/**
 * CACHED_b_clouds_file_bucket
 */
define('CACHED_b_clouds_file_bucket', 360000);

/**
 * CACHED_clouds_file_resize
 */
define('CACHED_clouds_file_resize', 360000);


?>